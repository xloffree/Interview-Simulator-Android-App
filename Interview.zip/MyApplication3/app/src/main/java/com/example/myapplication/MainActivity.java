package com.example.myapplication;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;



public class MainActivity extends Activity {
    MediaRecorder recorder;
    MediaPlayer player;


    static final String TAG = "MediaRecording";
    String outputFile;
    String answer = "";
    String[] questions = {"Why do you want to work here?","What is your greatest weakness?","What is your greatest strength?"};
    String[] answers = {"Answer 1","Answer 2","Answer 3"};
    Button recordButton, playbackButton;
    boolean isPlaying = false;
    boolean isRecording = false;
    boolean wordFound = false;
    boolean nextq = false;

    int x = (int) (Math.random() * ((3 - 1) + 1)) + 1;

    private static final int REQUEST_CODE = 100;
    private TextView textOutput;

    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            int MY_PERMISSIONS_RECORD_AUDIO = 1;
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_RECORD_AUDIO);

        } else if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            finish();

        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        requestPermissions();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recordButton = (Button) findViewById(R.id.startDictation);
        playbackButton = (Button) findViewById(R.id.button2);

        textOutput = (TextView) findViewById(R.id.textOutput);


        TextView theTextViewx = (TextView) findViewById(R.id.textViewx);

        theTextViewx.setText(questions[x - 1]);
        TextView theTextView = (TextView) findViewById(R.id.textViewtest);
        theTextView.setText("WELCOME!!!");
    }


    public void startRecording(View view) throws IOException {
        if (nextq) {
            x = (int) (Math.random() * ((3 - 1) + 1)) + 1;
            nextq = false;
            textOutput.setText("");
            TextView textViewAnswerz = (TextView)findViewById(R.id.textViewAnswer);
            textViewAnswerz.setText("");
            TextView theTextViewx = (TextView)findViewById(R.id.textViewx);
            theTextViewx.setText(questions[x - 1]);
            recordButton.setText("Start Dictation");
            return;
        }
        isRecording = !isRecording;
        if (isRecording) {
            recordButton.setText("Stop");
            //Creating file
            outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording.3gp";
            //Creating MediaRecorder and specifying audio source, output format, encoder & output format
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(outputFile);
            recorder.prepare();
            recorder.start();


        } else {
            stopRecording();
            recordButton.setText("Next Question");
            nextq = true;
        }
    }


    public void stopRecording() throws IOException {
        //stopping recorder
        if (null != recorder) {
            try {
                recorder.stop();
                recorder.release();
            } catch (RuntimeException ex) {
                //Ignore
            }
        }

    }
    public void listen() {
        boolean available = SpeechRecognizer.isRecognitionAvailable(this);
        if (available) {
            SpeechRecognizer sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                    wordFound = true;

                }

                @Override
                public void onError(int error) {

                }

                @Override
                public void onResults(Bundle results) {
                    if (wordFound) {
                        ArrayList<String> result = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        answer = answer + " " + result.get(0);
                        textOutput.setText(answer);
                    }
                    if (player.isPlaying()) {
                        listen();
                        wordFound = false;
                    } else {
                        isPlaying = false;
                        playbackButton.setText("Play Back Response");
                    }

                }


                @Override
                public void onPartialResults(Bundle partialResults) {
                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                }
                // define your other overloaded listener methods here
            });


            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            // the following appears to be a requirement, but can be a "dummy" value
            intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, "com.dummy");
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, new Long(5000));
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, new Long(5000));
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, new Long(5000));
            // define any other intent extras you want
            sr.startListening(intent);
            if (!isPlaying) {
                sr.destroy();
            }
        }
    }
    public void playAudio(View view) throws IOException {
        answer = "Your Answer: ";
        isPlaying = !isPlaying;
        if (isPlaying) {
            TextView theTextView = (TextView) findViewById(R.id.textViewtest);
            theTextView.setText("");

            TextView theTextViewx = (TextView) findViewById(R.id.textViewx);
            theTextViewx.setText("");
            TextView textViewAnswerz = (TextView) findViewById(R.id.textViewAnswer);
            textViewAnswerz.setText(answers[x - 1]);
                playbackButton.setText("Stop");
                player = new MediaPlayer();
                try {
                    player.setDataSource(outputFile);
                    player.prepare();
                    player.start();
                    listen();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                playbackButton.setText("Play Back Response");
                player.stop();
            }
        }
    }
